library(MASS)
library(leaps)
library(glmnet)
library(pls)


rm(list=ls())

data(Boston)
attach(Boston)

#Divide into Test and Train
n=nrow(Boston)
set.seed(1)
train=sample(1:n,0.8*n)


bost.train <-Boston[train,] 
bost.test <-Boston[-train,] 


#GET BEST SUBSET SELECTIONS AND FIND MSE WITH OOS FOR EACH. NOTE BEST
model <- regsubsets(crim ~ ., 
                    data = bost.train, 
                    nvmax = ncol(bost.train) - 1, 
                    method = "exhaustive")

# cross-validating to compare MSE:

CV_MSE <- c()

set.seed(1)

#GET RMSE FROM  EACH COMBINATION OF SUBSET OUTPUTS USING LM.
for (i in 1:(ncol(bost.train)-1)) {
  Boston_train <- bost.train[ ,c("crim", names(coef(model, id = i)[-1]))]
  BostonTrainLinearRegression = lm(crim~.,data=Boston_train)
  lm.pred <- predict(BostonTrainLinearRegression, newdata = bost.test)
  rmse_lm <- mean( (lm.pred- bost.test$crim)^2 )
  CV_MSE[i] <- rmse_lm
  print(names(coef(model, id = i)))
  print(rmse_lm)      
  
}

rmse_subsetselction<-min(CV_MSE)


#RIDGE REGRESSION
#Data Preperation Ridge and Lasso - Creating Interaction Variables

xtrain=model.matrix (crim~.,bost.train)[,-1]
ytrain=bost.train$crim
xtest=model.matrix (crim~.,bost.test)[,-1]
ytest=bost.test$crim


#Part C -  Ridge Regression
set.seed (1)

CV.R = cv.glmnet(xtrain,ytrain,alpha=0) # Do cross Validation
LamR = CV.R$lambda.1se 

model =glmnet(xtrain,ytrain,alpha=0,lambda=LamR)
pred=predict(model,s=LamR ,newx=xtest)
rmse_ridge=mean((pred-ytest)^2)

#Part D -  Lasso Regression
set.seed (1)

CV.L = cv.glmnet(xtrain,ytrain,alpha=1) # Do cross Validation
LamL = CV.L$lambda.1se 

model =glmnet(xtrain,ytrain,alpha=1,lambda=LamL)
pred=predict(model,s=LamL ,newx=xtest)
rmse_lasso=mean((pred-ytest)^2)

plot(log(CV.R$lambda),sqrt(CV.R$cvm),main="Ridge CV (k=10)",xlab="log(lambda)",ylab = "RMSE",col=4,type="b",cex.lab=1.2)
abline(v=log(LamR),lty=2,col=2,lwd=2)

plot(log(CV.L$lambda),sqrt(CV.L$cvm),main="Lasso CV (k=10)",xlab="log(lambda)",ylab = "RMSE",col=4,type="b",cex.lab=1.2)
abline(v=log(LamL),lty=2,col=2,lwd=2)

#Part E -  PCR 
library(pls) #USed for  both PCR and PLS

set.seed(1)

pcr.fit=pcr(crim~.,data=Boston,scale=TRUE,validation='CV',subset=train)
validationplot(pcr.fit,val.type="MSEP")
pcr.fit$ncomp

pcr.pred=predict(pcr.fit,newdata = Boston[-train,-c(1)],ncomp = 10)
rmse_pcr <- mean( (pcr.pred-Boston[-train,2])^2)
#resultant_rmse <- c(resultant_rmse, rmse_pcr=rmse_pcr)
