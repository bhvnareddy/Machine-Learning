#chapter 8, q8 
question='
In the lab, a classification tree was applied to the Carseats 
data set after converting Sales into a qualitative response 
variable. Now we will seek to predict Sales using regression
trees and related approaches, treating the response as a 
quantitative variable. 

(a) Split the data set into a training set and a test set. 

(b) Fit a regression tree to the training set.Plot the tree, 
and interpret the results. What test error rate do 
you obtain? 
  
(c) Use cross-validation in order to determine the optimal 
level of tree complexity. Does pruning the tree improve the test 
error rate? 
  
(d) Use the bagging approach in order to analyze this data. What 
test error rate do you obtain? Use the importance() function to 
determine which variables are most important. 

(e) Use random forests to analyze this data. What test error rate 
do you obtain? Use the importance() function to determine which 
variables are most important. Describe the effect of m, the 
num ber of variables considered at each split, on the
error rate obtained.    
'
library(ISLR)
attach(Carseats)
library(tree)
library(dplyr)
library(tidyverse)

#PART A -  Splitting and Sampling  the dataset
set.seed(2, sample.kind = "Rounding")

train_index <- sample(1:nrow(Carseats), nrow(Carseats) / 2)

train <- Carseats[train_index, ] # 200
test <- Carseats[-train_index, ] # 200

#Part B - Regression Tree
tree_model <- tree(Sales ~ ., train)
plot(tree_model)
text(tree_model, pretty = 0, cex = 0.7)

summary(tree_model)
test_pred <- predict(tree_model, test)
mean((test_pred - test$Sales)^2)

#Part C - Cross Validation and Pruning
set.seed(3)

cv_tree_model <- cv.tree(tree_model, K = 10)

set.seed(3)

cv_tree_model <- cv.tree(tree_model, K = 10)

data.frame(n_leaves = cv_tree_model$size,
           CV_RSS = cv_tree_model$dev)

pruned_tree_model <- prune.tree(tree_model, best = 16)
test_pred <- predict(pruned_tree_model, test)
mean((test_pred - test$Sales)^2)

#Part D - Bagging
set.seed(1)
set.seed(1)

bagged_trees_model <- randomForest(y = train$Sales, 
                                   x = train[ ,-1], 
                                   mtry = ncol(train) - 1, # 10
                                   importance = T) 
test_pred <- predict(bagged_trees_model, test)
mean((test_pred - test$Sales)^2)

importance(bagged_trees_model) %>%
  as.data.frame() %>%
  rownames_to_column("varname") %>%
  arrange(desc(IncNodePurity))

#PART E -  Random Forest
test_MSE <- c()

i <- 1


for (Mtry in 1:10) {
  set.seed(1)
  
  rf_temp <- randomForest(y = train$Sales, 
                          x = train[ ,-1], 
                          mtry = Mtry, 
                          importance = T)
  
  test_pred <- predict(rf_temp, test)
  
  test_MSE[i] <- mean((test_pred - test$Sales)^2)
  
  i <- i + 1
}
data.frame(mtry = 1:10, test_MSE = test_MSE)
tail(test_MSE, 1)
importance(rf_temp) %>%
  as.data.frame() %>%
  rownames_to_column("varname") %>%
  arrange(desc(IncNodePurity))
