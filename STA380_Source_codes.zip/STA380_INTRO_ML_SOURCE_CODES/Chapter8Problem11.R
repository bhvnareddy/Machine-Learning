#Loading packages
library(MASS)
library(ISLR)
library(gbm)

#Reading Caravan Data set
data("Caravan")
attach(Caravan)

#Creating training set of first 1000 variables 
train = 1:1000
Caravan$Purchase = ifelse(Caravan$Purchase == "Yes", 1, 0)
Caravan.train = Caravan[train,]

#Creating test set of remaining variables
Caravan.test = Caravan[-train,]

#Fitting a boosting model to the train data set 
set.seed(50)
boost.model = gbm(Purchase ~ ., data = Caravan.train, distribution = "gaussian", n.trees = 1000, shrinkage = 0.01)

#Obtaining variable importance 
par(mfrow = c(1,1))
p = ncol(Caravan.train)-1
var.importance = summary(boost.model,plotit=TRUE)


#Predicting response on test data - Boosting
pred.test1 <- predict(boost.model, Caravan.test, n.trees = 1000, type = "response")
pred.test1 <- ifelse(pred.test1 > 0.2, 1, 0)
table(Caravan.test$Purchase, pred.test1)

#Predicting response on test data - Logistic regression
logit.model <- glm(Purchase ~ ., data = Caravan.train, family = "binomial")
pred.test2 <- predict(logit.model, Caravan.test, type = "response")
pred.test2 <- ifelse(pred.test2 > 0.2, 1, 0)
table(Caravan.test$Purchase, pred.test2)



