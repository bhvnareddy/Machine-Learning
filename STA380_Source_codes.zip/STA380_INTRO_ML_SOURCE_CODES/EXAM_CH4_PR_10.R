#Loading packages
library(ISLR)
library(ggplot2)
library(reshape2)
library(corrplot)
library(class)
library(kknn)

#Reading Weekly data
data("Weekly")
attach(Weekly)

#Corrplot summary for Weekly
summary(Weekly)


#Part A - Corelation between variables 
#Encoding Direction as UP = 1 and DOWN =0
Weekly$Direction = ifelse(Weekly$Direction == "Up", 1, 0)

#Plotting correlation matrix
cormat <- round(cor(Weekly),2)
melted_cormat <- melt(cormat)
head(melted_cormat)

get_upper_tri <- function(cormat){
  cormat[lower.tri(cormat)]<- NA
  return(cormat)
}

upper_tri <- get_upper_tri(cormat)

melted_cormat <- melt(upper_tri, na.rm = TRUE)
ggheatmap <- ggplot(melted_cormat, aes(Var2, Var1, fill = value))+
  geom_tile(color = "white")+
  scale_fill_gradient2(low = "blue", high = "red", mid = "white",
                       midpoint = 0, limit = c(-1,1), space = "Lab",
                       name="Pearson\nCorrelation") +
  theme_minimal()+ # minimal theme
  theme(axis.text.x = element_text(angle = 45, vjust = 1,
                                   size = 12, hjust = 1))+
  coord_fixed()

ggheatmap +
  geom_text(aes(Var2, Var1, label = value), color = "black", size = 3) +
  theme(
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    panel.grid.major = element_blank(),
    panel.border = element_blank(),
    panel.background = element_blank(),
    axis.ticks = element_blank(),
    legend.justification = c(1, 0),
    legend.position = c(0.6, 0.7),
    legend.direction = "horizontal")+
  guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                               title.position = "top", title.hjust = 0.5))


#PArt B - Logistic Regression 
Weekly.logReg1<-glm(Direction~Lag1+Lag2+Lag3+Lag4+Lag5+Volume, data=Weekly,family="binomial")
summary(Weekly.logReg1)

#Confusion Matrix
pred.testw1 <- predict(Weekly.logReg1, Weekly, type = "response")
pred.testw1 <- ifelse(pred.testw1 > 0.5, '1', '0')
table(Weekly$Direction, pred.testw1)

#Part C - KNN
train = (Year<2009)
Weekly.test <-Weekly[!train,]
Weekly.logReg2<-glm(Direction~Lag2, data=Weekly,family=binomial, subset=train)
prob.testw2= predict(Weekly.logReg2, Weekly.test, type = "response")
pred.testw2 = rep("Down", length(prob.testw2))
pred.testw2[prob.testw2 > 0.5] = "Up"
table(pred.testw2, Direction[!train])

#knn for k=1 
Week.train=as.matrix(Lag2[train])
Week.test=as.matrix(Lag2[!train])
train.Direction =Direction[train]
set.seed(1)
Weekknn.pred=knn(Week.train,Week.test,train.Direction,k=1)
table(Weekknn.pred,Direction.0910)

#Part D  - Various interactions 
#Logistic Regression with Interaction Lag2:Lag4
Weekly.fit<-glm(Direction~Lag2:Lag4+Lag2, data=Weekly,family=binomial, subset=train)
logWeekly.prob= predict(Weekly.fit, Weekly.0910, type = "response")
logWeekly.pred = rep("Down", length(logWeekly.prob))
logWeekly.pred[logWeekly.prob > 0.5] = "Up"
Direction.0910 = Direction[!train]
table(logWeekly.pred, Direction.0910)

mean(logWeekly.pred == Direction.0910)

#LDA with Interaction Lag2:Lag4
Weeklylda.fit<-lda(Direction~Lag2:Lag4+Lag2, data=Weekly,family=binomial, subset=train)
Weeklylda.pred<-predict(Weeklylda.fit, Weekly.0910)
table(Weeklylda.pred$class, Direction.0910)

Weeklyqda.fit = qda(Direction ~ poly(Lag2,2), data = Weekly, subset = train)
Weeklyqda.pred = predict(Weeklyqda.fit, Weekly.0910)$class
table(Weeklyqda.pred, Direction.0910)

#PART E AND F SKIPPED AS PER INSTRUCTIONS. 

#Part G - K=10
Week.train=as.matrix(Lag2[train])
Week.test=as.matrix(Lag2[!train])
train.Direction =Direction[train]
set.seed(1)
Weekknn.pred=knn(Week.train,Week.test,train.Direction,k=10)
table(Weekknn.pred,Direction.0910)

#K=100
Week.train=as.matrix(Lag2[train])
Week.test=as.matrix(Lag2[!train])
train.Direction =Direction[train]
set.seed(1)
Weekknn.pred=knn(Week.train,Week.test,train.Direction,k=100)
table(Weekknn.pred,Direction.0910)



