#Imprt Dataset


library(ISLR)
library(glmnet)


rm(list=ls())

college <- College
attach(college)
head(college,10)



#resultant RMSE from different models saved in
resultant_rmse<-c()

#Part A - Divide the set into training and test - Train : Test Ratio used is 50:50
n=nrow(College)
set.seed(100)
train=sample(1:n,0.7*n)


coll.train <-College[train,] 
coll.test <-College[-train,] 


#Part B - Run Linear Regression
lm.fit  <- lm(Apps~.,data=coll.train)
lm.pred <- predict(lm.fit,newdata = coll.test)
rmse_lm <- mean( (lm.pred-coll.test$Apps )^2 )
resultant_rmse <- c(resultant_rmse, rmse_lm=rmse_lm)

#Part C  - Data Preperation Ridge and Lasso - Creating Interaction Variables
grid = 10 ^ seq(4, -2, length=100)

xtrain=model.matrix (Apps~.,coll.train)[,-1]
ytrain=coll.train$Apps
xtest=model.matrix (Apps~.,coll.test)[,-1]
ytest=coll.test$Apps


#Part C -  Ridge Regression
set.seed (1)

CV.R = cv.glmnet(xtrain,ytrain,alpha=0) # Do cross Validation
LamR = CV.R$lambda.1se 

model =glmnet(xtrain,ytrain,alpha=0,lambda=LamR)
pred=predict(model,s=LamR ,newx=xtest)
rmse_ridge=mean((pred-ytest)^2)
resultant_rmse <- c(resultant_rmse, rmse_ridge=rmse_ridge)

#Part D -  Lasso Regression
set.seed (1)

CV.L = cv.glmnet(xtrain,ytrain,alpha=1) # Do cross Validation
LamL = CV.L$lambda.1se 

model =glmnet(xtrain,ytrain,alpha=1,lambda=LamL)
pred=predict(model,s=LamL ,newx=xtest)
rmse_lasso=mean((pred-ytest)^2)
resultant_rmse <- c(resultant_rmse, rmse_lasso=rmse_lasso)

lasso_coef <- predict(model, type = "coefficients", lambda = LamL)

#Plot Figures for aesthetics
par(mfrow=c(1,2))
plot(log(CV.R$lambda),sqrt(CV.R$cvm),main="Ridge CV (k=10)",xlab="log(lambda)",ylab = "RMSE",col=4,type="b",cex.lab=1.2)
abline(v=log(LamR),lty=2,col=2,lwd=2)

plot(log(CV.L$lambda),sqrt(CV.L$cvm),main="LASSO CV (k=10)",xlab="log(lambda)",ylab = "RMSE",col=4,type="b",cex.lab=1.2)
abline(v=log(LamL),lty=2,col=2,lwd=2)


#Getting Nonzero Coeffe
lasscoef=predict(model,type="coefficients",s=LamL)[1:length(model$beta),]
#Printing non zero coefficients
lasscoef[lasscoef!=0]

#Part E -  PCR 
library(pls) #USed for  both PCR and PLS

set.seed(1)
x<-c()
pcr.fit=pcr(Apps~.,data=College,scale=TRUE,validation='CV',subset=train)
validationplot(pcr.fit,val.type="MSEP")
pcr.fit$ncomp

pcr.pred=predict(pcr.fit,newdata = College[-train,-c(2)],ncomp = 9)
rmse_pcr <- mean( (pcr.pred-College[-train,2])^2)
resultant_rmse <- c(resultant_rmse, rmse_pcr=rmse_pcr)


#Part F - PLS

pls.fit=plsr(Apps~.,data=College,scale=TRUE,validation='CV',subset=train)
validationplot(pls.fit,val.type="MSEP")
pls.fit$ncomp

pls.pred=predict(pls.fit,newdata = College[-train,-c(2)],ncomp = 6)
rmse_pls<-mean( (pls.pred-College[-train,2])^2)
resultant_rmse <- c(resultant_rmse, rmse_pls=rmse_pls)

sort(resultant_rmse)

