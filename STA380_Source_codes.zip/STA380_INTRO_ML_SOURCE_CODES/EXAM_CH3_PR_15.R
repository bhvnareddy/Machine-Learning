library(MASS)
data("Boston")
attach(Boston)

#Q3, Chapter 15, Part A: CHECK LINEAR MODEL FOR ALL PREDICTOR VARIABLES WITH CRIM
fit.zn <- lm(crim ~ zn)
summary(fit.zn)

fit.indus <- lm(crim ~ indus)
summary(fit.indus)

chas <- as.factor(chas)
fit.chas <- lm(crim ~ chas)
summary(fit.chas)

fit.nox <- lm(crim ~ nox)
summary(fit.nox)

fit.rm <- lm(crim ~ rm)
summary(fit.rm)

fit.age <- lm(crim ~ age)
summary(fit.age)

fit.dis <- lm(crim ~ dis)
summary(fit.dis)

fit.rad <- lm(crim ~ rad)
summary(fit.rad)

fit.tax <- lm(crim ~ tax)
summary(fit.tax)

fit.ptratio <- lm(crim ~ ptratio)
summary(fit.ptratio)

fit.black <- lm(crim ~ black)
summary(fit.black)

fit.lstat <- lm(crim ~ lstat)
summary(fit.lstat)

fit.medv <- lm(crim ~ medv)
summary(fit.medv)

#Q3 Part B - MULTIPLE LINEAR REGRESSION
fit.all <- lm(crim ~ ., data = Boston)
summary(fit.all)

#Q3 Part C - PLOT 
simple.reg <- vector("numeric",0)
simple.reg <- c(simple.reg, fit.zn$coefficient[2])
simple.reg <- c(simple.reg, fit.indus$coefficient[2])
simple.reg <- c(simple.reg, fit.chas$coefficient[2])
simple.reg <- c(simple.reg, fit.nox$coefficient[2])
simple.reg <- c(simple.reg, fit.rm$coefficient[2])
simple.reg <- c(simple.reg, fit.age$coefficient[2])
simple.reg <- c(simple.reg, fit.dis$coefficient[2])
simple.reg <- c(simple.reg, fit.rad$coefficient[2])
simple.reg <- c(simple.reg, fit.tax$coefficient[2])
simple.reg <- c(simple.reg, fit.ptratio$coefficient[2])
simple.reg <- c(simple.reg, fit.black$coefficient[2])
simple.reg <- c(simple.reg, fit.lstat$coefficient[2])
simple.reg <- c(simple.reg, fit.medv$coefficient[2])
mult.reg <- vector("numeric", 0)
mult.reg <- c(mult.reg, fit.all$coefficients)
mult.reg <- mult.reg[-1]
plot(simple.reg, mult.reg, col = "red")

#Q3 PART D - CHECK WITH POLYNOMIAL RELATION 
fit.zn2 <- lm(crim ~ poly(zn, 3))
summary(fit.zn2)

fit.indus2 <- lm(crim ~ poly(indus, 3))
summary(fit.indus2)


fit.nox2 <- lm(crim ~ poly(nox, 3))
summary(fit.nox2)

fit.rm2 <- lm(crim ~ poly(rm, 3))
summary(fit.rm2)

fit.age2 <- lm(crim ~ poly(age, 3))
summary(fit.age2)

fit.dis2 <- lm(crim ~ poly(dis, 3))
summary(fit.dis2)

fit.rad2 <- lm(crim ~ poly(rad, 3))
summary(fit.rad2)

fit.tax2 <- lm(crim ~ poly(tax, 3))
summary(fit.tax2)

fit.ptratio2 <- lm(crim ~ poly(ptratio, 3))
summary(fit.ptratio2)

fit.black2 <- lm(crim ~ poly(black, 3))
summary(fit.black2)

fit.lstat2 <- lm(crim ~ poly(lstat, 3))
summary(fit.lstat2)

fit.medv2 <- lm(crim ~ poly(medv, 3))
summary(fit.medv2)
