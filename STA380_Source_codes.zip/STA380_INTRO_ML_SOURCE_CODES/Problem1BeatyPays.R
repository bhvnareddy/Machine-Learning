library(reshape2)
library(ggplot2)

bd <- read.csv('BeautyData.csv')

#Q2 Part A : Number of rows
nrows = dim(bd)[1]
ncolumns = dim(bd)[2]

#To get understanding of variables, we use three stratergies
# 1. Correlation
# 2. Multiple Linear Regression
# 3. Forward , Backward and StepSelection 
#Features are concluded at the end. 

#Draw Corelation Between Variables
cormat <- round(cor(bd),2)
melted_cormat <- melt(cormat)
head(melted_cormat)

get_upper_tri <- function(cormat){
  cormat[lower.tri(cormat)]<- NA
  return(cormat)
}

upper_tri <- get_upper_tri(cormat)

melted_cormat <- melt(upper_tri, na.rm = TRUE)
ggheatmap <- ggplot(melted_cormat, aes(Var2, Var1, fill = value))+
  geom_tile(color = "white")+
  scale_fill_gradient2(low = "blue", high = "red", mid = "white",
                       midpoint = 0, limit = c(-1,1), space = "Lab",
                       name="Pearson\nCorrelation") +
  theme_minimal()+ # minimal theme
  theme(axis.text.x = element_text(angle = 45, vjust = 1,
                                   size = 12, hjust = 1))+
  coord_fixed()

ggheatmap +
  geom_text(aes(Var2, Var1, label = value), color = "black", size = 3) +
  theme(
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    panel.grid.major = element_blank(),
    panel.border = element_blank(),
    panel.background = element_blank(),
    axis.ticks = element_blank(),
    legend.justification = c(1, 0),
    legend.position = c(0.6, 0.7),
    legend.direction = "horizontal")+
  guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                               title.position = "top", title.hjust = 0.5))


#Proves, One on One correlation betweeen CourseEvals ad BEauty score
#To confirm the causation between the two we will perform MLR


#Interpret from MLR
bd <- read.csv('BeautyData.csv')
Y <- log(bd$CourseEvals)


bd <- bd[,-c(1)] # lose lmedval and the room totals
n = dim(bd)[1]
set.seed(1)
tr = sample(1:n,350)


BDdata = data.frame(Y,scale(bd))
mlr = lm(Y~., data=BDdata[tr,])
summary(mlr)



#Forwards / Backward Search Sratergy 
bd <- read.csv('BeautyData.csv')

Y <- log(bd$CourseEvals)

bd <- bd[,-c(1)] # lose lmedval and the room totals
n = dim(bd)[1]
set.seed(1)
tr = sample(1:n,350)



XXbeauty <- model.matrix(~.*BeautyScore*female*lower*nonenglish*tenuretrack, data=data.frame(scale(bd)))[,-1]

BDdata = data.frame(Y,XXbeauty)

null = lm(Y~1, data=BDdata[tr,])
full = lm(Y~., data=BDdata[tr,])

regForward = step(null, scope=formula(full), direction="forward", k=log(length(tr)))
regBack = step(full, direction="backward", k=log(length(tr)))
regStep = step(null, scope=formula(full), direction="both", k=log(length(tr)))

full = lm(CourseEvals~., data=bd)
summary(full)



