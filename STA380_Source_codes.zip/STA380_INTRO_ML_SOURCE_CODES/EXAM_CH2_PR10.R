library(MASS) ## a library of example datasets
library(class) ## a library with lots of classification tools
library(kknn) ## knn library
library(reshape2)
library(ggplot2)

attach(Boston)

#Q2 Part A : Number of rows
nrows = dim(Boston)[1]
ncolumns = dim(Boston)[2]

cat(' Number of Rows ' , nrows , ' \n Number of Columns ', ncolumns)
dim(Boston)
cat('Number of Columns ' , ncolumns)

#Draw Corelation Between Variables
cormat <- round(cor(Boston),2)
melted_cormat <- melt(cormat)
head(melted_cormat)
get_upper_tri <- function(cormat){
  cormat[lower.tri(cormat)]<- NA
  return(cormat)
}

upper_tri <- get_upper_tri(cormat)


melted_cormat <- melt(upper_tri, na.rm = TRUE)
ggheatmap <- ggplot(melted_cormat, aes(Var2, Var1, fill = value))+
  geom_tile(color = "white")+
  scale_fill_gradient2(low = "blue", high = "red", mid = "white",
                       midpoint = 0, limit = c(-1,1), space = "Lab",
                       name="Pearson\nCorrelation") +
  theme_minimal()+ # minimal theme
  theme(axis.text.x = element_text(angle = 45, vjust = 1,
                                   size = 12, hjust = 1))+
  coord_fixed()

ggheatmap +
  geom_text(aes(Var2, Var1, label = value), color = "black", size = 2) +
  theme(
    axis.title.x = element_blank(),
    axis.title.y = element_blank(),
    panel.grid.major = element_blank(),
    panel.border = element_blank(),
    panel.background = element_blank(),
    axis.ticks = element_blank(),
    legend.justification = c(1, 0),
    legend.position = c(0.6, 0.7),
    legend.direction = "horizontal")+
  guides(fill = guide_colorbar(barwidth = 7, barheight = 1,
                               title.position = "top", title.hjust = 0.5))


#Q2 PART B
#Scatter plots 
#1. Medv vs. Lstat 
#2. Medv vs. rm 
#3. Dis vs. age 
#4. Ptratio vs. nox

par(mfrow=c(2,2))
plot(medv,lstat, main="Scatterplot of medv vs. lstat" , sub="Shows High Negative Correlation (-0.74)")
plot(medv,rm, main="Scatterplot of medv vs rm", sub="Shows High Positive Correlation (0.7)")
plot(dis, age , main="Scatterplot of dis vs age" , sub="Shows High Negative Correlation (-0.75)")
plot(ptratio, nox, main="Scatterplot of ptratio vs nox", sub="Shows Low Correlation (0.19)")

#Q2 PART C
#Corelation for crim VARIABLE ONLY
CRIM_CORR=melted_cormat[melted_cormat$Var1 == "crim" & melted_cormat$Var2 != "crim",]
CRIM_CORR$absvalue=abs(as.numeric(CRIM_CORR$value))
CRIM_CORR <- CRIM_CORR[order(-CRIM_CORR$absvalue),]

p<-ggplot(data=CRIM_CORR, aes(x = reorder(Var2, -absvalue) , y=value)) +
  geom_bar(stat="identity", fill="steelblue")+
  geom_text(aes(label=value), vjust=-0.3, size=2.5)+
  theme_minimal()


p

#Q2 PART D
#Check 3rd Quartile Value and Max Value. See if there exists High 
summary(crim)
ggplot(Boston, aes(x = crim)) + 
  geom_histogram(binwidth = 0.25, fill = "deepskyblue") + 
  labs(title = "CRIM - Histogram", 
       x = "crim", 
       y = "Count")
summary(tax)

ggplot(Boston, aes(x = tax)) + 
  geom_histogram(binwidth = 10, fill = "mediumseagreen") + 
  scale_y_continuous(breaks = seq(0, 200, 20)) +
  labs(title = "Tax - Histogram", 
       x = "Tax", 
       y = "Count")

summary(ptratio)
ggplot(Boston, aes(x = ptratio)) + 
  geom_histogram(binwidth = 0.25, fill = "deepskyblue") + 
  scale_x_continuous(breaks = seq(12, 23, 0.5)) + 
  scale_y_continuous(breaks = seq(0, 200, 20)) + 
  labs(title = "Ptratio - Histogram", 
       x = "Ptratio", 
       y = "Count")

#Q2 PART E
#How many of the suburbs in this data set bound the Charles river?

table(Boston$chas)

#Q2 PART F
#What is the median pupil-teacher ratio among the towns in this data set?
median(ptratio)

#Q2 PART G
Boston[medv == min(medv),]

#Q2 PART H
nrow(Boston[rm>7,])
nrow(Boston[rm>8,])

