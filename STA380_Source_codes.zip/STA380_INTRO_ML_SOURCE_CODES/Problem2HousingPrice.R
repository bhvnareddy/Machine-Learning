rm(list=ls())

#Data Read and Prep
MidCity = read.csv("MidCity.csv",header=T)
attach(MidCity)

MidCity <- MidCity[,-c(1)]

n = dim(MidCity)[1]


#Creating Different Arrays for each Neighbourhood, and Labelleing BRICK
dn1 = rep(0,n)
dn1[Nbhd==1]=1
dn2 = rep(0,n)
dn2[Nbhd==2]=1
dn3 = rep(0,n)
dn3[Nbhd==3]=1
BR = rep(0,n)
BR[Brick=="Yes"]=1

#Scale Variables Price and SqFt to avoid Magnitude Bias
Price = Price/1000
SqFt = SqFt/1000

#Remove dn1 - Creates high corelation with other dummy variables dn2 and dn3, take n-1 dummy variables.

MidCityPrepped <- data.frame(Price ,  dn2, dn3, BR, SqFt, MidCity$Bedrooms , MidCity$Bathrooms , MidCity$Offers)

#Problem A - Is there a premium for brick houses, everything else being equal
MidCityReg = lm(Price~.,data=MidCityPrepped)
summary(MidCityReg)

#BR is very important as it has a t value of 8.729. Indicating that coeffecient would 
#be zero only for points occuring 8.7 Standard Errors away from the Estimate 17.297. Which is less than 1.78*10^-14 chance

#Problem B - Premium for houses in Neighbourhood 3

#dn3 indicates s. 

#Problem C - Extra premium for brick houses in neihbourhood3. 
#Create INteraction VAriable  - BR.dn3

MidCityReg = lm(Price~dn2+dn3+BR+SqFt+MidCity$Bedrooms+MidCity$Bathrooms+MidCity$Offers+BR:dn3,data=MidCityPrepped)
summary(MidCityReg)

#Problem D - Check if N2 and N1 have no significance on their own

MidCityPrepped <- data.frame(Price ,dn2, dn3, BR, SqFt, MidCity$Bedrooms , MidCity$Bathrooms , MidCity$Offers)
MidCityReg = lm(Price~.,data=MidCityPrepped)
summary(MidCityReg)


MidCityPrepped <- data.frame(Price ,dn1, dn3, BR, SqFt, MidCity$Bedrooms , MidCity$Bathrooms , MidCity$Offers)
MidCityReg = lm(Price~.,data=MidCityPrepped)
summary(MidCityReg)

#This proves that both and N1 and N2 dont have individual importance, so we dont lose much by combinign them


